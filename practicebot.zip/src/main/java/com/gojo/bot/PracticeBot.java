package com.gojo.bot;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class PracticeBot implements ModInitializer {

    /** One difficulty preset. Null item = nothing in that slot. */
    record Level(String name, Item sword, Item helmet, Item chest, Item legs, Item boots,
                 double speed, double health, double strafePower, int heals, double jumpChance) {
    }

    static final Level EASY = new Level("easy", Items.WOODEN_SWORD, Items.LEATHER_HELMET, null, null, null,
            0.23, 20, 0.0, 0, 0.0);
    static final Level MEDIUM = new Level("medium", Items.STONE_SWORD, Items.IRON_HELMET, Items.IRON_CHESTPLATE, null, null,
            0.26, 20, 0.03, 1, 0.02);
    static final Level HARD = new Level("hard", Items.IRON_SWORD, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            0.29, 24, 0.05, 3, 0.04);

    static class Bot {
        final ZombieEntity entity;
        final ServerPlayerEntity owner;
        final Level level;
        int heals;
        int strafeDir = 1;
        int strafeTimer = 10;
        int healCooldown = 0;
        int jumpCooldown = 0;

        Bot(ZombieEntity entity, ServerPlayerEntity owner, Level level) {
            this.entity = entity;
            this.owner = owner;
            this.level = level;
            this.heals = level.heals();
        }
    }

    static final List<Bot> BOTS = new ArrayList<>();

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("bot")
                        .then(CommandManager.literal("spawn")
                                .executes(c -> spawn(c, MEDIUM))
                                .then(CommandManager.literal("easy").executes(c -> spawn(c, EASY)))
                                .then(CommandManager.literal("medium").executes(c -> spawn(c, MEDIUM)))
                                .then(CommandManager.literal("hard").executes(c -> spawn(c, HARD))))
                        .then(CommandManager.literal("clear").executes(PracticeBot::clear))));

        ServerTickEvents.END_SERVER_TICK.register(server -> tick());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> BOTS.clear());
    }

    private static int spawn(CommandContext<ServerCommandSource> ctx, Level lvl) {
        ServerCommandSource src = ctx.getSource();
        ServerPlayerEntity player = src.getPlayer();
        if (player == null) {
            src.sendError(Text.literal("Ye command player ke liye hai."));
            return 0;
        }
        ServerWorld world = src.getWorld();

        ZombieEntity bot = new ZombieEntity(world);
        Vec3d look = player.getRotationVec(1.0f);
        double x = player.getX() + look.x * 6;
        double z = player.getZ() + look.z * 6;
        bot.setPosition(x, player.getY(), z);
        bot.setYaw(player.getYaw() + 180f);

        bot.setBaby(false);
        bot.setPersistent();
        bot.setCustomName(Text.literal("Bot [" + lvl.name() + "]"));
        bot.setCustomNameVisible(true);

        equip(bot, EquipmentSlot.MAINHAND, lvl.sword());
        equip(bot, EquipmentSlot.HEAD, lvl.helmet());
        equip(bot, EquipmentSlot.CHEST, lvl.chest());
        equip(bot, EquipmentSlot.LEGS, lvl.legs());
        equip(bot, EquipmentSlot.FEET, lvl.boots());

        bot.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(lvl.health());
        bot.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED).setBaseValue(lvl.speed());
        bot.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE).setBaseValue(1.0);
        bot.getAttributeInstance(EntityAttributes.FOLLOW_RANGE).setBaseValue(64.0);
        bot.setHealth((float) lvl.health());
        bot.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 999999, 0, false, false));
        bot.setTarget(player);

        world.spawnEntity(bot);
        BOTS.add(new Bot(bot, player, lvl));

        src.sendFeedback(() -> Text.literal("Bot aa gaya (" + lvl.name() + "). All the best!"), false);
        return 1;
    }

    private static void equip(ZombieEntity bot, EquipmentSlot slot, Item item) {
        if (item != null) bot.equipStack(slot, new ItemStack(item));
    }

    private static int clear(CommandContext<ServerCommandSource> ctx) {
        int n = BOTS.size();
        for (Bot b : BOTS) b.entity.discard();
        BOTS.clear();
        ctx.getSource().sendFeedback(() -> Text.literal(n + " bot hata diye."), false);
        return n;
    }

    private static void tick() {
        Iterator<Bot> it = BOTS.iterator();
        while (it.hasNext()) {
            Bot b = it.next();
            ZombieEntity e = b.entity;

            if (e.isRemoved()) {
                it.remove();
                continue;
            }
            if (!e.isAlive()) {
                b.owner.sendMessage(Text.literal("GG! Bot haar gaya (" + b.level.name() + ")"), true);
                it.remove();
                continue;
            }
            if (b.owner.isRemoved()) {
                e.discard();
                it.remove();
                continue;
            }

            if (e.getTarget() != b.owner) e.setTarget(b.owner);

            if (b.healCooldown > 0) b.healCooldown--;
            if (b.jumpCooldown > 0) b.jumpCooldown--;

            double dx = b.owner.getX() - e.getX();
            double dz = b.owner.getZ() - e.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            ThreadLocalRandom rnd = ThreadLocalRandom.current();

            // Strafe around the player when close
            if (b.level.strafePower() > 0 && dist < 5.0 && dist > 0.2) {
                if (--b.strafeTimer <= 0) {
                    b.strafeDir = -b.strafeDir;
                    b.strafeTimer = 10 + rnd.nextInt(20);
                }
                double px = -dz / dist * b.strafeDir;
                double pz = dx / dist * b.strafeDir;
                e.addVelocity(px * b.level.strafePower(), 0, pz * b.level.strafePower());
            }

            // Jump hits (crit attempts) when in melee range
            if (b.level.jumpChance() > 0 && dist < 3.0 && e.isOnGround()
                    && b.jumpCooldown <= 0 && rnd.nextDouble() < b.level.jumpChance()) {
                e.addVelocity(0, 0.42, 0);
                b.jumpCooldown = 20;
            }

            // Heal (gap) when low
            if (b.heals > 0 && b.healCooldown <= 0 && e.getHealth() < e.getMaxHealth() * 0.4f) {
                e.heal(8.0f);
                e.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 1200, 0));
                b.heals--;
                b.healCooldown = 40;
                b.owner.sendMessage(Text.literal("Bot ne gap kha li! (" + b.heals + " bachi)"), true);
            }
        }
    }
}
